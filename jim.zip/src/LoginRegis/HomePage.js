// import React from 'react';
// import { Link } from 'react-router-dom';
// import './HomePage.css';
// import '../App.css'

// export default function HomePage() {
//     return (
//         <div className="text-center">
//             <h1 className="main-title home-page-title">TRF Sections</h1>
//             <Link to="/">
//                 <button className="primary-button" id="reg_btn"><span>Log Out</span></button>
//             </Link>
//         </div>
//     )
// }
